/*#define ones portd.b0
#define tens portd.b1
#define auto_manual portb.b2
void counter(signed char count ){
char left = count/10 ; //first digit
char right = count%10 ;    //last digit
tens = 0 ;      //pnp2 is on
ones = 1 ;      //pnp1 is off
portc = right ;
delay_ms(10) ;
tens = 1 ;        //pnp 2 is off
ones = 0 ;         //pnp 1 is on
portc = left ;
delay_ms(10) ;
}
char interrupt_count  = 0 ;
void interrupt(){
if(INTF_BIT == 1 ) {
INTF_BIT = 0 ;
}
interrupt_count ++ ;
}
void auto_mode(char r ) {
signed char count ;
unsigned char i ;
switch(r) {
case 1 :
for(count = 15 ; count > 0 ; count --){
if(auto_manual == 0 )
{
interrupt_count = 0 ;
portd = 0b0000011 ;
break ; }
if(count <=3 ){
portd.b7 = 0 ;
portd.b6 = 1 ;
}
else
{
portd.b2 = 1 ;
portd.b7 = 1 ;
}
for(i = 0 ; i <=50 ; i ++) {
counter(count) ;
}       }
portd = 0b0000011 ;
break ;

case 2 :
for(count = 23 ; count > 0 ; count --) {
if(auto_manual == 0 ) {
interrupt_count = 0 ;
portd = 0b0000011 ;
break ;
}
if(count <= 3 ) {
 portd.b4 = 0 ;
 portd.b3 = 1 ;
}
else {
portd.b6 = 0 ;
portd.b5 = 1 ;
portd.b4 = 1 ;
portd.b2 = 0 ;
}
for(i = 0 ; i <= 50 ; i ++) {
counter(count) ;
}
}
 portd = 0b0000011 ;
 break ;

}
 }

void main() {
signed char count ;
unsigned char i ;
TRISB = 1 ; //port b is input
GIE_bit=1;
INTEDG_bit=0;   //falling edge
INTE_bit=1;
NOT_RBPU_bit = 0 ;     //pull up activated
TRISC = 0 ;   //port c for segments
PORTC = 0 ;  //segment is 0 at first
TRISD = 0 ;  //port D is output
PORTD = 0b0000011 ; // all leds are off , pnp1 is off ,pnp2 is off
//for automatic display
for( ; ; ){
portd = 0b0000011 ;
// automatic mode
while(auto_manual==1){
auto_mode(1) ;
auto_mode(2) ;
}
//manual mode

while(auto_manual == 0){
switch(interrupt_count) {
case 1 :   //red and green are on
portd.b2 = 1  ;
portd.b7 = 1 ;
break ;
case 2 : //red and yellow
portd = 0b01000111 ;
for(count = 3 ; count > 0 ; count --) {
 for(i = 0 ; i < 50 ; i ++){
 counter(count) ;
 }
}
portd =0b00000011 ;
if(auto_manual== 1 ) {
auto_mode(2) ;
break ;
}
else {
interrupt_count = 3 ;
break ;
}
case 3 :
portd = 0b00110011 ;
if(auto_manual==1) {
 portd =0b00000011 ;
 portd = 0b00101011 ;
 for(count = 3 ; count > 0 ; count --) {
 for(i = 0 ; i < 50 ; i ++){
 counter(count) ;
 }
}
break ;
}
else {
break ; }
case 4 :
portd = 0b00101011 ;
for(count = 3 ; count > 0 ; count --) {
 for(i = 0 ; i < 50 ; i ++){
 counter(count) ;
 }
}
portd = 0b00000011 ;
interrupt_count = 1 ;
break ;

}
}

}
 }  */

#define ones portd.b0
#define tens portd.b1
#define auto_manual portb.b2
void counter(signed char count ){
char left = count/10 ; //first digit
char right = count%10 ;    //last digit
tens = 0 ;      //pnp2 is on
ones = 1 ;      //pnp1 is off
portc = right ;
delay_ms(10) ;
tens = 1 ;        //pnp 2 is off
ones = 0 ;         //pnp 1 is on
portc = left ;
delay_ms(10) ;
}

char interrupt_count  = 0 ;
void interrupt(){
if(INTF_BIT == 1 ) {
INTF_BIT = 0 ;
}
interrupt_count ++ ;
}

void auto_mode(char r ) {
signed char count ;
unsigned char i ;
switch(r) {



case 1 :
for(count = 15 ; count > 0 ; count --){
if(auto_manual == 0 )
{
interrupt_count = 0 ;
portd = 0b0000011 ;
break ; }
if(count <=3 ){
portd.b7 = 0 ;
portd.b6 = 1 ;
}
else
{
portd.b2 = 1 ;
portd.b7 = 1 ;
}
for(i = 0 ; i <=50 ; i ++) {
counter(count) ;
}       }
portd = 0b0000011 ;
break ;

case 2 :
for(count = 23 ; count > 0 ; count --) {
if(auto_manual == 0 ) {
interrupt_count = 0 ;
portd = 0b0000011 ;
break ;
}
if(count <= 3 ) {
 portd.b4 = 0 ;
 portd.b3 = 1 ;
}
else {
portd.b6 = 0 ;
portd.b5 = 1 ;
portd.b4 = 1 ;
portd.b2 = 0 ;
}
for(i = 0 ; i <= 50 ; i ++) {
counter(count) ;
}
}
 portd = 0b0000011 ;
 break ;

}
 }

void main() {
signed char count ;
unsigned char i ;
TRISB = 1 ; //port b is input
GIE_bit=1;
INTEDG_bit=0;   //falling edge
INTE_bit=1;
NOT_RBPU_bit = 0 ;     //pull up activated
TRISC = 0 ;   //port c for segments
PORTC = 0 ;  //segment is 0 at first
TRISD = 0 ;  //port D is output
PORTD = 0b0000011 ; // all leds are off , pnp1 is off ,pnp2 is off
//for automatic display
for( ; ; ){
//portd = 0b0000011 ;
// automatic mode
while(auto_manual==1){
if(portd = 0b00110011 && interrupt_count == 3 ) {
 portd =0b00000011 ;
 portd = 0b00101011 ;
 for(count = 3 ; count > 0 ; count --) {
 for(i = 0 ; i < 50 ; i ++){
 counter(count) ;
 }
}
portd =0b00000011 ;
if(auto_manual==0) {
interrupt_count = 1 ;
break ;
}
portd =0b00000011 ;
auto_mode(1) ;
}
else
{
portd =0b00000011 ;
auto_mode(1) ;
auto_mode(2) ;
}
}

//manual mode

while(auto_manual == 0){
switch(interrupt_count) {
case 1 :   //red and green are on
portd.b2 = 1  ;
portd.b7 = 1 ;
break ;
case 2 : //red and yellow
portd = 0b01000111 ;
for(count = 3 ; count > 0 ; count --) {
 for(i = 0 ; i < 50 ; i ++){
 counter(count) ;
 }
}
portd =0b00000011 ;
if(auto_manual== 1 ) {
auto_mode(2) ;
break ;
}
else {
interrupt_count = 3 ;
break ;
}
case 3 :
portd = 0b00110011 ;
if(auto_manual==1)
break ;
else
break ;
case 4 :
portd = 0b00101011 ;
for(count = 3 ; count > 0 ; count --) {
 for(i = 0 ; i < 50 ; i ++){
 counter(count) ;
 }
}
portd = 0b00000011 ;
interrupt_count = 1 ;
break ;

}
}

}
 }